/*
 * File:	checker.cpp
 *
 * Description:	This file contains the public and private function and
 *		variable definitions for the semantic checker for Simple C.
 *
 *		If a symbol is redeclared, the redeclaration is discarded
 *		and the original declaration is retained.
 *
 *		Extra functionality:
 *		- inserting an undeclared symbol with the error type
 */

#include <iostream>
#include "lexer.h"
#include "checker.h"
#include "tokens.h"
#include "Symbol.h"
#include "Scope.h"
#include "Type.h"

using namespace std;

static Scope *outermost, *toplevel;
static const Type error;
static const Type integer(INT);
static const Type longtype(LONG);

static string redefined = "redefinition of '%s'";
static string redeclared = "redeclaration of '%s'";
static string conflicting = "conflicting types for '%s'";
static string undeclared = "'%s' undeclared";
static string void_object = "'%s' has type void";

static string e1 = "invalid return type";
static string e2 = "invalid type for test expression";
static string e3 = "lvalue required in expression";
static string e4 = "invalid operands to binary %s";
static string e5 = "invalid operand to unary %s";
static string e6 = "called object is not a function";
static string e7 = "invalid arguments to called function";

/*
 * Function:	openScope
 *
 * Description:	Create a scope and make it the new top-level scope.
 */

Scope *openScope()
{
    toplevel = new Scope(toplevel);

    if (outermost == nullptr)
        outermost = toplevel;

    return toplevel;
}

/*
 * Function:	closeScope
 *
 * Description:	Remove the top-level scope, and make its enclosing scope
 *		the new top-level scope.
 */

Scope *closeScope()
{
    Scope *old = toplevel;
    toplevel = toplevel->enclosing();
    return old;
}

/*
 * Function:	defineFunction
 *
 * Description:	Define a function with the specified NAME and TYPE.  A
 *		function is always defined in the outermost scope.  This
 *		definition always replaces any previous definition or
 *		declaration.
 */

Symbol *defineFunction(const string &name, const Type &type)
{
    cout << name << ": " << type << endl;
    Symbol *symbol = outermost->find(name);

    if (symbol != nullptr)
    {
        if (symbol->type().isFunction() && symbol->type().parameters())
        {
            report(redefined, name);
            delete symbol->type().parameters();
        }
        else if (type != symbol->type())
            report(conflicting, name);

        outermost->remove(name);
        delete symbol;
    }

    symbol = new Symbol(name, type);
    outermost->insert(symbol);
    return symbol;
}

/*
 * Function:	declareFunction
 *
 * Description:	Declare a function with the specified NAME and TYPE.  A
 *		function is always declared in the outermost scope.  Any
 *		redeclaration is discarded.
 */

Symbol *declareFunction(const string &name, const Type &type)
{
    cout << name << ": " << type << endl;
    Symbol *symbol = outermost->find(name);

    if (symbol == nullptr)
    {
        symbol = new Symbol(name, type);
        outermost->insert(symbol);
    }
    else if (type != symbol->type())
    {
        report(conflicting, name);
        delete type.parameters();
    }
    else
        delete type.parameters();

    return symbol;
}

/*
 * Function:	declareVariable
 *
 * Description:	Declare a variable with the specified NAME and TYPE.  Any
 *		redeclaration is discarded.
 */

Symbol *declareVariable(const string &name, const Type &type)
{
    cout << name << ": " << type << endl;
    Symbol *symbol = toplevel->find(name);

    if (symbol == nullptr)
    {
        if (type.specifier() == VOID && type.indirection() == 0)
            report(void_object, name);

        symbol = new Symbol(name, type);
        toplevel->insert(symbol);
    }
    else if (outermost != toplevel)
        report(redeclared, name);

    else if (type != symbol->type())
        report(conflicting, name);

    return symbol;
}

/*
 * Function:	checkIdentifier
 *
 * Description:	Check if NAME is declared.  If it is undeclared, then
 *		declare it as having the error type in order to eliminate
 *		future error messages.
 */

Symbol *checkIdentifier(const string &name)
{
    Symbol *symbol = toplevel->lookup(name);

    if (symbol == nullptr)
    {
        report(undeclared, name);
        symbol = new Symbol(name, error);
        toplevel->insert(symbol);
    }

    return symbol;
}



// STATEMENTS
Type checkReturn(const Type &left, const Type &return_type) {
    if(left.isError() || return_type.isError())
        return error;

    if(left.isCompatibleWith(return_type))
        return left;
    
    report(e1);
    return error;
}

Type checkIfWhileFor(const Type &left) {
    if(left.isError())
        return error;
    
    if(left.isPredicate())
        return left;
    
    report(e2);
    return error;
}

Type checkAssignment(const Type &left, const Type &right, const bool &lvalue) {
    if(left.isError() || right.isError()) 
        return error;

    if(lvalue == false) {
        report(e3);
        return error;
    }

    if(left.isCompatibleWith(right))
        return left;

    report(e4, "=");
    return error;
}



// LOGICAL EXPRESSIONS
Type checkLogical(const Type &left, const Type &right, const string &op) {
    if(left.isError() || right.isError()) 
        return error;

    Type promo_left = left.promote();
    Type promo_right = right.promote();

    if(promo_left.isPredicate() && promo_right.isPredicate())
        return integer;

    report(e4, op);
    return error;
}



// EQUALITY EXPRESSIONS
Type checkEquality(const Type &left, const Type &right, const string &op) {
    if(left.isError() || right.isError()) {
        return error;
    }

    Type promo_left = left.promote();
    Type promo_right = right.promote();

    if(promo_left.isCompatibleWith(promo_right)) {
        return integer;
    }

    report(e4, op);
    return error;
}



// RELATIONAL EXPRESSIONS
Type checkRelational(const Type &left, const Type &right, const string &op) {
    if(left.isError() || right.isError())
        return error;

    Type promo_left = left.promote();
    Type promo_right = right.promote();

    if((promo_left.isNumeric() && promo_right.isNumeric()) 
        || (promo_left == promo_right && promo_left.isPredicate() && promo_right.isPredicate()))
        return integer;

    report(e4, op);
    return error;
}



// ADDITIVE EXPRESSIONS
Type checkAdd(const Type &left, const Type &right) {
    if(left.isError() || right.isError())
        return error;

    Type promo_left = left.promote();
    Type promo_right = right.promote();

    if(promo_left.isNumeric() && promo_right.isNumeric()) {
        if(promo_left.specifier() == LONG || promo_right.specifier() == LONG)
            return longtype;
        else 
            return integer;
    } else if(promo_left.isPointer() && promo_left.specifier() != VOID && promo_right.isNumeric()) {
        return promo_left;
    } else if(promo_left.isNumeric() && promo_right.isPointer() && promo_right.specifier() != VOID) {
        return promo_right;
    }

    report(e4, "+");
    return error;
}

Type checkSub(const Type &left, const Type &right) {
    if(left.isError() || right.isError())
        return error;

    Type promo_left = left.promote();
    Type promo_right = right.promote();

    if(promo_left.isNumeric() && promo_right.isNumeric()) {
        if(promo_left.specifier() == LONG || promo_right.specifier() == LONG)
            return longtype;
        else 
            return integer;
    } else if(promo_left.isPointer() && promo_left.specifier() != VOID && promo_right.isNumeric()) {
        return promo_left;
    } else if(promo_left.isPointer() && promo_right.isPointer() && promo_left.specifier() == promo_right.specifier() && promo_left.specifier() != VOID) {
        return longtype;
    }

    report(e4, "-");
    return error;
}



// MULTIPLICATIVE EXPRESSIONS
Type checkMulDivMod(const Type &left, const Type &right, const string &op) {
    if(left.isError() || right.isError())
        return error;

    if(left.isNumeric() && right.isNumeric()) {
        if(left.specifier() == LONG || right.specifier() == LONG)
            return longtype;
        else 
            return integer;
    }

    report(e4, op);
    return error;
}



// PREFIX EXPRESSIONS
Type checkDeref(const Type &left) {
    if(left.isError())
        return error;

    Type promo_left = left.promote();

    if(promo_left.isPointer() && promo_left.specifier() != VOID) 
        return Type(promo_left.specifier(), promo_left.indirection()-1);
    
    report(e5, "*");
    return error;
}

Type checkAddress(const Type &left, const bool &lvalue) {
    if(left.isError())
        return error;

    if(lvalue)
        return Type(left.specifier(), left.indirection()+1);

    report(e3);
    return error;
}

Type checkNot(const Type &left) {
    if(left.isError())
        return error;

    if(left.isPredicate())
        return integer;

    report(e5, "-");
    return error;
}

Type checkNeg(const Type &left) {
    if(left.isError())
        return error;

    Type promo_left = left.promote();

    if(promo_left.isNumeric()) 
        return promo_left;
    
    report(e5, "-");
    return error;
}

Type checkSizeof(const Type &left) {
    if(left.isError())
        return error;

    if(left.isPredicate()) 
        return longtype;
    
    report(e5, "sizeof");
    return error;
}



// POSTFIX EXPRESSIONS
Type checkIndexing(const Type &left, const Type &right) {
    if(left.isError() || right.isError()) 
        return error;

    Type promo_left = left.promote();
    Type promo_right = right.promote();

    if(promo_left.isPointer() && promo_left != Type(VOID, 1) && promo_right.isNumeric())
        return Type(promo_left.specifier(), promo_left.indirection()-1);
    
    report(e4, "[]");
    return error;
}



// FUNCTION CALLS
Type checkFunctionCalls(const Type &left, Parameters *args) {
    if(left.isError())
        return error;

    // if not a fucntion, e6
    if(!left.isFunction()) {
        report(e6);
        return error;
    }

    // check same # of args and params, else e7
    // buster causing a seg fault
    // if(left.parameters()->size() != args->size()) {
    //     report(e7);
    //     return error;
    // }

    if(left.parameters() != nullptr && args != nullptr) {
        if(left.parameters()->size() != args->size()) {
            report(e7);
            return error;
        } 

        // check args are predicate and agree with params, else e7
        for(unsigned i = 0; i < args->size(); i++) {
            Type promo_arg = args->at(i).promote();
            Type promo_left = left.parameters()->at(i).promote();
            
            if(!(promo_arg.isPredicate()) || !(promo_left.isCompatibleWith(promo_arg))) {
                report(e7);
                return error;
            }
        }
    }
    
    return Type(left.specifier(), left.indirection());
}


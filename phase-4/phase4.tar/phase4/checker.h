/*
 * File:	checker.h
 *
 * Description:	This file contains the public function declarations for the
 *		semantic checker for Simple C.
 */

# ifndef CHECKER_H
# define CHECKER_H
# include "Scope.h"

Scope *openScope();
Scope *closeScope();

Symbol *defineFunction(const std::string &name, const Type &type);
Symbol *declareFunction(const std::string &name, const Type &type);
Symbol *declareVariable(const std::string &name, const Type &type);
Symbol *checkIdentifier(const std::string &name);

Type checkLogical(const Type &left, const Type &right, const std::string &op);
Type checkReturn(const Type &left, const Type &return_type);
Type checkIfWhileFor(const Type &left);
Type checkAssignment(const Type &left, const Type &right, const bool &lvalue);
Type checkRelational(const Type &left, const Type &right, const std::string &op);
Type checkEquality(const Type &left, const Type &right, const std::string &op);
Type checkAdd(const Type &left, const Type &right);
Type checkSub(const Type &left, const Type &right);
Type checkMulDivMod(const Type &left, const Type &right, const std::string &op);
Type checkDeref(const Type &right);
Type checkAddress(const Type &right, const bool &lvalue);
Type checkNot(const Type &right);
Type checkNeg(const Type &right);
Type checkSizeof(const Type &right);
Type checkIndexing(const Type &left, const Type &right);
Type checkFunctionCalls(const Type &left, Parameters *params);

# endif /* CHECKER_H */

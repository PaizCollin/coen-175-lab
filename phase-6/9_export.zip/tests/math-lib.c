/* math-lib.c (use gcc math.s math-lib.c) */

int x, f();

int main(void) {
    f(23, 46, 3);
    printf("%d\n", x);
}
/* math.c (use ./scc < math.c > math.s) */

int x;
int f(int a, int b, int c) {
    x = a + b * c;
}
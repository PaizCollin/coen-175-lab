#include "generator.h"
#include <iostream>

using namespace std;

static ostream &operator<<(ostream &ostr, Expression *expr) {
    expr->operand(ostr);

    return ostr;
}

void Block::generate() {
    for(auto stmt: _stmts) {
        stmt->generate();
    }

    return;
}

void Simple::generate() {
    _expr->generate();
    
    return;
}

void Expression::operand(ostream &ostr) const {
    return;
}

void Number::operand(ostream &ostr) const {
    ostr << "$" << this->value();
    return;
}

void Identifier::operand(ostream &ostr) const {
    if(this->symbol()->_offset == 0) {
        ostr << this->symbol()->name();
    } else {
        ostr << this->symbol()->_offset << "(%rbp)";
    }

    return;
}

void generateGlobals(Scope *scope) {
    for(unsigned i = 0; i < scope->symbols().size(); i++) {
        if(!scope->symbols().at(i)->type().isFunction()) {
            cout << ".comm " << scope->symbols().at(i)->name() << ", " << scope->symbols().at(i)->type().size() << endl;
        }
    }
    return;
}

void Function::generate() {
    int offsetCounter = 0;

    for(unsigned i = 0; i < _body->declarations()->symbols().size(); i++) {
        offsetCounter -= _body->declarations()->symbols().at(i)->type().size();
        _body->declarations()->symbols().at(i)->_offset = offsetCounter;
    }

    while(offsetCounter % 16 != 0) {
        offsetCounter--;
    }

    cout << _id->name() << ":" << endl;

    // prologue
    cout << "pushq %rbp" << endl;
    cout << "movq %rsp, %rbp" << endl;
    cout << "subq $" << -offsetCounter << ", %rsp" << endl;

    // spill
    string registers[6] = {
    "\%edi", "\%esi", "\%edx", "\%ecx", "\%r8d", "\%r9d" };

    for(unsigned i = 0; i < _id->type().parameters()->size(); i++) { 
        cout << "movl " << registers[i] << ", " << _body->declarations()->symbols().at(i)->_offset << "(%rbp)" << endl;
    }

    // body
    _body->generate();

    // epilogue
    cout << "movq %rbp, %rsp" << endl;
    cout << "popq %rbp" << endl;
    cout << "ret" << endl;

    // output .global directive
    cout << ".globl " << _id->name() << endl;
}

void Assignment::generate() {
    cout << "movl " << _right << ", " << _left << endl;
    return;
}

void Call::generate() {
    string registers[6] = {
    "\%edi", "\%esi", "\%edx", "\%ecx", "\%r8d", "\%r9d" };

    for(unsigned i = 0; i < _args.size(); i++) {
        cout << "movl " << _args.at(i) << ", " << registers[i] << endl;
    }
    
    cout << "call " << _id->name() << endl;
    return;
}
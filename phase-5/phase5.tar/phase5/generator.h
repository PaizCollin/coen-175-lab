# ifndef GENERATOR_H
# define GENERATOR_H
# include "Tree.h"

void generateGlobals(Scope *scope);

# endif